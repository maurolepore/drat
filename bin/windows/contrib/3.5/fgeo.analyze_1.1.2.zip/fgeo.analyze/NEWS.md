# fgeo.analyze (development version)

* Work in progress.

# fgeo.analyze 1.1.2 (GitHub and drat release)

* Use tidy versions.

# fgeo.analyze 1.1.1 (GitHub and drat release)

* fgeo.x no longer is imported but suggested.

# fgeo.analyze 1.1.0 (GitHub release)

* Import fgeo packages via `Additional_repositories` served at <https://forestgeo.github.io/drat/>

* First argument of most visible functions now follow tidyverse principles (<http://bit.ly/2TfDcfX>).

# fgeo.analyze 1.0.3 (GitHub and drat release)

* Released version now uses released versions recursively via @*release.

# fgeo.analyze 1.0.2 (GitHub release)

* Tidy dependencies.

# fgeo.analyze 1.0.1 (GitHub release)

* Review documentation.

# fgeo.analyze 1.0.0 (GitHub release)

* Initial release.
