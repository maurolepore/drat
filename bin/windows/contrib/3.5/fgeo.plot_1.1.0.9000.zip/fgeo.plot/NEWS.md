# fgeo.plot (development version)

* Work in progress.

# fgeo.plot 1.1.0 (GitHub release)

* fgeo.x no longer is imported but instead is suggested.

* Import fgeo packages via `Additional_repositories` served at <https://forestgeo.github.io/drat/>.

* First argument of most visible functions now follow tidyverse principles (<http://bit.ly/2TfDcfX>).

# fgeo.plot 1.0.4 (GitHub and drat release)

* Use release version recursively via @*release.

# fgeo.plot 1.0.3 (GitHub release)

* Prune dependencies.

# fgeo.plot 1.0.2 (GitHub release)

* Style.
* Review documentation.

# fgeo.plot 1.0.0 (GitHub release)

* Initial GitHub release. For CRAN, fgeo.tool and fgeo.x must be released first.

