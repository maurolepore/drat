# fgeo.krig (development version)

* Work in progress.

# fgeo.krig 1.0.1 ([GitHub](https://github.com/forestgeo/fgeo.krig/releases) and [drat](https://forestgeo.github.io/drat/))

This release marks that __fgeo.krig__ now meets CRAN standards. The only user-facing change is that __fgeo.krig__ requires R version 3.3 or later. [All other changes](../CHANGELOG.md) are internal and focused on making the package more reliable and easier to maintain.

# fgeo.krig 1.0.0 ([GitHub](https://github.com/forestgeo/fgeo.krig/releases) and [drat](https://forestgeo.github.io/drat/))

* Initial release.
