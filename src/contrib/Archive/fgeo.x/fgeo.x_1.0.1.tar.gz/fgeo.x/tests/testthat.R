library(testthat)
library(fgeo.x)

test_check("fgeo.x")
