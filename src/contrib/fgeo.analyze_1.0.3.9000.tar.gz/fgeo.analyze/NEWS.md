# fgeo.analyze (development version)

* Work in progress.

# fgeo.analyze 1.0.3 (GitHub release)

* Released version now uses released versions recursively via @*release.

# fgeo.analyze 1.0.2 (GitHub release)

* Tidy dependencies.

# fgeo.analyze 1.0.1 (GitHub release)

* Review documentation.

# fgeo.analyze 1.0.0 (GitHub release)

* Initial GitHub release. For CRAN, fgeo.x and fgeo.tool must be released first.
