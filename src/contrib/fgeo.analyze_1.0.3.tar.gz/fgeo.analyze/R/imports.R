#' @importFrom dplyr group_by ungroup filter select mutate summarize arrange
#' @importFrom dplyr count
#' @importFrom fgeo.tool check_crucial_names is_duplicated is_multiple
#' @importFrom fgeo.tool rename_matches
#' @importFrom glue glue glue_collapse
#' @importFrom grDevices dev.off graphics.off pdf
#' @importFrom graphics hist lines par plot points text
#' @importFrom MASS boxcox
#' @importFrom rlang abort inform warn expr eval_tidy expr_label %||% set_names
#' @importFrom stats dnorm median optim qbeta qt quantile rgamma rnorm runif sd
#' @importFrom stats nls var nls.control predict resid
#' @importFrom tibble tibble as.tibble as_tibble
NULL

#' Pipe operator
#'
#' See \code{magrittr::\link[magrittr]{\%>\%}} for details.
#'
#' @name %>%
#' @rdname pipe
#' @keywords internal
#' @export
#' @importFrom magrittr %>%
#' @usage lhs \%>\% rhs
NULL

# Avoid CMD check warnings
utils::globalVariables(c(".data", ".", "n"))
