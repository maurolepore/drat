library(testthat)
library(fgeo.analyze)

test_check("fgeo.analyze")
