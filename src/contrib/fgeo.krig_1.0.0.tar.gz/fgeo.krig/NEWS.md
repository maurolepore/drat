# fgeo.krig (development version)

* Work in progress.

# fgeo.krig 1.0.0 (GitHub and drat release)

* Initial release.
