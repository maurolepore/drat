library(testthat)
library(fgeo.krig)

test_check("fgeo.krig")
