# fgeo.plot (development version)

* Work in progress.

# fgeo.plot 1.0.4 (GitHub release)

* Use release version recrsively via @*release.

# fgeo.plot 1.0.3 (GitHub release)

* Prune dependencies.

# fgeo.plot 1.0.2 (GitHub release)

* Style.
* Review documentation.

# fgeo.plot 1.0.0 (GitHub release)

* Initial GitHub release. For CRAN, fgeo.tool and fgeo.x must be released first.

