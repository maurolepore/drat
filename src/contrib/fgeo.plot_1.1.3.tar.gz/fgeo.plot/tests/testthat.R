library(testthat)
library(fgeo.plot)

test_check("fgeo.plot")
