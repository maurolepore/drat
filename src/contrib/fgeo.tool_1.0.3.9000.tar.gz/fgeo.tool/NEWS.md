# fgeo.tool (development version)

* Work in progress.

# fgeo.tool 1.0.3 (GithHub release)

* Use released versions recursively via @*release.

# fgeo.tool 1.0.2 (GithHub release)

* Tidy dependencies.

# fgeo.tool 1.0.1 (GithHub release)

* Review documentation.

# fgeo.tool 1.0.0 (GithHub release)

* Initial GitHub release. For CRAN submission, fgeo.x must be submitted first.
