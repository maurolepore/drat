# fgeo.tool (development version)

* Work in progress.

# fgeo.tool 1.1.0 (GithHub release)

* First argument of most visible functions are now named following tidyverse principles (<http://bit.ly/2TfDcfX>)

# fgeo.tool 1.0.3 (GitHub and drat release)

* Release on CRAN-like repository served at <https://forestgeo.github.io/drat/>.
* Use released versions recursively via @*release.

# fgeo.tool 1.0.2 (GithHub release)

* Tidy dependencies.

# fgeo.tool 1.0.1 (GithHub release)

* Review documentation.

# fgeo.tool 1.0.0 (GithHub release)

* Initial GitHub release. For CRAN submission, fgeo.x must be submitted first.
