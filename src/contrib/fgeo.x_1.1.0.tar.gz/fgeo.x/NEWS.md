# fgeo.x (development version)

* Work in progress.

# fgeo.x 1.1.0 (GithHub release)

* First argument of most visible functions are now named following tidyverse principles (<http://bit.ly/2TfDcfX>)

# fgeo.x 1.0.1 (GitHub and drat release)

* Review documentation.

# fgeo.x 1.0.0 (GitHub release)

* Initial GitHub release. Passes all checks required for submission to CRAN.
