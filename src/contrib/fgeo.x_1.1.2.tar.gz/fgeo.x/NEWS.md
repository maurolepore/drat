# fgeo.x (development version)

* Work in progress.

# fgeo.x 1.1.2 ([GitHub](https://github.com/forestgeo/fgeo.x/releases) and [drat](https://forestgeo.github.io/drat/))

* Maintenance release.

# fgeo.x 1.1.1 ([GitHub](https://github.com/forestgeo/fgeo.x/releases) and [drat](https://forestgeo.github.io/drat/))

_fgeo.x_ now requires R >= 3.2.

# fgeo.x 1.1.0 ([GitHub](https://github.com/forestgeo/fgeo.x/releases) and [drat](https://forestgeo.github.io/drat/))

* Meet CRAN standards.
* First argument of most visible functions are now named following tidyverse principles (<http://bit.ly/2TfDcfX>).

# fgeo.x 1.0.1 ([GitHub](https://github.com/forestgeo/fgeo.x/releases) and [drat](https://forestgeo.github.io/drat/))

* Review documentation.

# fgeo.x 1.0.0 ([GitHub](https://github.com/forestgeo/fgeo.x/releases))

* Initial release.
