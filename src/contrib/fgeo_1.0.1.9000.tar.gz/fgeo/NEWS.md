# fgeo (development version)

* Work in progress.

# fgeo 1.0.1 (GitHub release)

* Style.
* Tidy dependencies.

# fgeo 1.0.0 (GitHub release)

* Internal GitHub release.
