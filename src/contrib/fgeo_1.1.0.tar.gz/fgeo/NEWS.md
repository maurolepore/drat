# fgeo (development version)

* Work in progress.

# fgeo 1.1.0 (GitHub release)

* Import fgeo packages via `Additional_repositories` served at <https://forestgeo.github.io/drat/>

# fgeo 1.0.1 (GitHub and drat release)

* Style.

* Tidy dependencies.

# fgeo 1.0.0 (GitHub release)

* Internal release.
